# goidentity

Standard interface for holding authenticated identities and their attributes.

This project has now been converted to use Go modules. Please refer to the latest major version sub directory.
This follows the practice outlines at https://blog.golang.org/v2-go-modules

[![Version](https://img.shields.io/github/v/release/jcmturner/goidentity?label=Version&sort=semver)](https://github.com/jcmturner/goidentity/releases)

